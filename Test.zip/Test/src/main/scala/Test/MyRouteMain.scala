package Test

import org.apache.spark.{SparkConf, SparkContext}

/*import org.apache.camel.main.Main
import org.apache.camel.scala.dsl.builder.RouteBuilderSupport*/

/**
 * A Main to run Camel with MyRouteBuilder
 */
object MyRouteMain {

  def main(args: Array[String]) {
    //println("hello world!")
    val conf = new SparkConf().setMaster("local").setAppName("WenlongTestApplication")
    val sc = new SparkContext(conf);
    //val rdd = sc.wholeTextFiles("file:///home/pm/data/wenlong/data") // this works!
    val rdd = sc.textFile("hdfs://localhost:10000/pm/midt/output/mktitins") // this works too.
    val array = rdd.take(10)
    array.foreach(println)

    println("Run Successfully!")
  }
}

